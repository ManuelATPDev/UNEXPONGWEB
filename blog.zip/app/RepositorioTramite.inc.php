<?php

include_once 'app/config.inc.php';
include_once 'app/Conexion.inc.php';
include_once 'app/Tramite.inc.php';

class RepositorioTramite {
    
    public static function insertar_tramite($conexion, $tramite) {
        $tramite_insertado = false;

        if (isset($conexion)) {
            try {
                $sql = "INSERT INTO tramites(autor_id, tipo, fecha, tramite_activo) VALUES(:autor_id, :tipo, NOW(), 0)";
                
                $sentencia = $conexion->prepare($sql);

                $autor_idtemp = $tramite->obtener_autor_id();
                $tipotemp = $tramite->obtener_tipo();

                $sentencia->bindParam(':autor_id', $autor_idtemp, PDO::PARAM_STR);
                $sentencia->bindParam(':tipo', $tipotemp, PDO::PARAM_STR);
                

                $tramite_insertado = $sentencia->execute();
            } catch (PDOException $ex) {
                print "ERROR" . $ex->getMessage();
            }
        }

        return $tramite_insertado;
    }
    
    public static function contar_tramites_activos($conexion,$id_usuario){
        $total_tramites = 0;
    
        if (isset($conexion)) {
            try {
                $sql = 'SELECT COUNT(*) as total_tramites FROM tramites WHERE autor_id = :autor_id AND tramite_activo=1';
                $sentencia = $conexion->prepare($sql);
                
                $sentencia->bindParam(':autor_id', $id_usuario, PDO::PARAM_STR);
                $sentencia-> execute();
                $resultado = $sentencia -> fetch();
                
                if (!empty($resultado)){
                    $total_tramites = $resultado['total_tramites'];
                }
            } catch (PDOException $ex) {
                print 'ERROR' . $ex -> getMessage();
            }
        }
        
        return $total_tramites;
    }
    
    public static function contar_tramites_inactivos($conexion,$id_usuario){
        $total_tramites = 0;
    
        if (isset($conexion)) {
            try {
                $sql = 'SELECT COUNT(*) as total_tramites FROM tramites WHERE autor_id = :autor_id AND tramite_activo=0';
                $sentencia = $conexion->prepare($sql);
                
                $sentencia->bindParam(':autor_id', $id_usuario, PDO::PARAM_STR);
                $sentencia-> execute();
                $resultado = $sentencia -> fetch();
                
                if (!empty($resultado)){
                    $total_tramites = $resultado['total_tramites'];
                }
            } catch (PDOException $ex) {
                print 'ERROR' . $ex -> getMessage();
            }
        }
        
        return $total_tramites;
    }
}
