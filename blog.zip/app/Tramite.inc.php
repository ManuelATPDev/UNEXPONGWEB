<?php

class Tramite {

    private $id;
    private $autor_id;
    private $tipo;
    private $fecha;
    private $tramite_activo;

    public function __construct($id, $autor_id, $tipo, $fecha, $tramite_activo) {
        $this->id = $id;
        $this->autor_id = $autor_id;
        $this->tipo = $tipo;
        $this->fecha = $fecha;
        $this->tramite_activo = $tramite_activo;
    }

    public function obtener_id() {
        return $this->id;
    }

    public function obtener_autor_id() {
        return $this->autor_id;
    }
    
    public function obtener_tipo() {
        return $this->tipo;
    }

    public function obtener_fecha() {
        return $this->fecha;
    }

    public function esta_tramite_activo() {
        return $this->tramite_activo;
    }
    
    public function cambiar_tramite_activo($tramite_activo) {
        $this->tramite_activo = $tramite_activo;
    }

}

