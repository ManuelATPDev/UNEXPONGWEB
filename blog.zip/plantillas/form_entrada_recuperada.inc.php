<br>
<input type="hidden" id="id_entrada" name="id_entrada" value="<?php echo $id_entrada; ?>">
<div class="form-group">
    <label for="titulo">TÍTULO</label>
    <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Escriba su título" value="<?php echo $entrada_recuperada -> obtener_titulo(); ?>">
    <input type="hidden" id="titulo_original" name="titulo_original" value="<?php echo $entrada_recuperada ->obtener_titulo();  ?>"
</div>
<div class="form-group">
    <label for="titulo">URL</label>
    <input type="text" class="form-control" id="url" name="url" placeholder="Escriba su dirección única sin espacios" value="<?php echo $entrada_recuperada -> obtener_url(); ?>">
    <input type="hidden" id="url_original" name="url_original" value="<?php echo $entrada_recuperada ->obtener_url();  ?>"
</div>
<div class="form-group">
    <label for="texto">TEXTO</label>
    <textarea class="form-control" rows="10" id="texto" name="texto" placeholder="Escriba su contenido"><?php echo $entrada_recuperada -> obtener_texto(); ?></textarea>
    <input type="hidden" id="texto_original" name="texto_original" value="<?php echo $entrada_recuperada ->obtener_texto();  ?>"
</div>
<div class="checkbox">
    <label>
        <input type="checkbox" name="publicar" value="si" <?php if($entrada_recuperada->esta_activa()){echo 'checked';} ?>>Publicar de inmediato
        <input type="hidden" id="publicar_original" name="publicar_original" value="<?php echo $entrada_recuperada ->esta_activa();  ?>"
    </label>
</div>
<br>
<div class="text-center">
    <button type="submit" class="btn btn-success" name="guardar_cambios">Guardar cambios</button>
    <br>
    <br>
</div>
