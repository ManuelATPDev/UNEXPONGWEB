<?php
include_once 'app/EscritorEntradas.inc.php';
include_once 'plantillas/documento-apertura.inc.php';
?>

<div class="row">
    <div class="col-md-12">
        <br>
        <h3>
            Otras entradas que te podrian interesar:
        </h3>
        <br>
    </div>

    <?php
    for ($i = 0; $i < count($entradas_al_azar); $i++) {
        $entradas_actual = $entradas_al_azar[$i];
        ?>

        <div class="col-md-4">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo $entradas_actual->obtener_titulo(); ?>
                </div>
                <div class="panel-body">
                    <p>
                        <?php echo EscritorEntradas::resumir_texto(nl2br($entradas_actual->obtener_texto())); ?>
                    </p>
                </div>
            </div>
        </div>
        <?php
    }
    ?>
    <div class="col-md-12">
        <hr>
    </div>
</div>

<?php
    include_once 'plantillas/documento-cierre.inc.php';
?>