<br>
<?php $gestor_actual?>
<div class="container">
    <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
            <ul class="nav nav-sidebar">
                <li><a href="<?php echo RUTA_GESTOR_ENTRADAS ?>">Entradas</a></li>
                <li><a href="<?php echo RUTA_GESTOR_COMENTARIOS?>">Comentarios</a></li>
                <li><a href="<?php echo RUTA_GESTOR_TRAMITES?>">Trámites</a></li>
            </ul>
        </div>
        <div class="col-sm-9 col-md-10 main">
            
        
