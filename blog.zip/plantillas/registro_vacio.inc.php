<div class="form-group">
    <label>Nombre</label>
    <input type="text" class="form-control" name="nombre" placeholder="Leunam" >
</div>
<div class="form-group">
    <label>Apellido</label>
    <input type="text" class="form-control" name="apellido" placeholder="Villamizar" >
</div>
<div class="form-group">
    <label>Cédula</label>
    <input type="number" min="0" max="999999999" class="form-control" name="cedula" placeholder="12345678">
</div>
<div class="form-group">
    <label>Expediente</label>
    <input type="number" min="0" max="9999999999" class="form-control" name="expediente" placeholder="1234567890">
</div>
<div class="form-group">
    <label>Especialidad</label>
    <input type="text" class="form-control" name="especialidad" placeholder="Mecatrónica">
</div>
<div class="form-group">
    <label>Correo Electrónico</label>
    <input type="email" class="form-control" name="email" placeholder="usuario@mail.com">
</div>
<div class="form-group">
    <label>Contraseña</label>
    <input type="password" class="form-control" name="clave" placeholder="Contraseña">
</div>
<div class="form-group">
    <label>Repite la contraseña</label>
    <input type="password" class="form-control" name="clave2" placeholder="Contraseña anterior">
</div>
<br>
<button type="reset" class="btn btn-default btn-primary">Resetear el formulario</button>
<button type="submit" class="btn btn-default btn-primary" name="enviar">Unirse a la UNEXPO</button>

