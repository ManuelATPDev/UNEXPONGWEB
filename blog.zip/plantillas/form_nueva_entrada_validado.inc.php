<br>
<div class="form-group">
    <label for="titulo">TÍTULO</label>
    <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Escriba su título" <?php $entrada_recuperada -> mostrar_titulo() ?>> <br><?php $entrada_recuperada -> mostrar_error_titulo();?><br>
</div>
<div class="form-group">
    <label for="titulo">URL</label>
    <input type="text" class="form-control" id="url" name="url" placeholder="Escriba su dirección única sin espacios" <?php $entrada_recuperada->mostrar_url() ?>> <br><?php $entrada_recuperada->mostrar_error_url();?><br>
</div>
<div class="form-group">
    <label for="texto">TEXTO</label>
    <textarea class="form-control" rows="10" id="texto" name="texto" placeholder="Escriba su contenido"><?php $entrada_recuperada -> mostrar_texto() ?></textarea> <br><?php $entrada_recuperada->mostrar_error_texto();?><br>
</div>
<div class="checkbox">
    <label><input type="checkbox" name="publicar" value="si" <?php if ($entrada_publica) {echo 'checked';}?> >Publicar de inmediato</label>
</div>
<br>
<div class="text-center">
    <button type="submit" class="btn btn-success" name="guardar">Guardar Entrada</button>
    <br>
    <br>
</div>
