<br>
<div class="form-group">
    <label for="titulo">TÍTULO</label>
    <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Escriba su título">
</div>
<div class="form-group">
    <label for="titulo">URL</label>
    <input type="text" class="form-control" id="url" name="url" placeholder="Escriba su dirección única sin espacios">
</div>
<div class="form-group">
    <label for="texto">TEXTO</label>
    <textarea class="form-control" rows="10" id="texto" name="texto" placeholder="Escriba su contenido"></textarea>
</div>
<div class="checkbox">
    <label><input type="checkbox" name="publicar" value="si">Publicar de inmediato</label>
</div>
<br>
<div class="text-center">
    <button type="submit" class="btn btn-success" name="guardar">Guardar Entrada</button>
    <br>
    <br>
</div>