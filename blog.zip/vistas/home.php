<?php
include_once 'app/Conexion.inc.php';
include_once 'app/RepositorioUsuario.inc.php';
include_once 'app/EscritorEntradas.inc.php';

$titulo = 'UNEXPO Núcleo Guarenas';

include_once 'plantillas/documento-apertura.inc.php';
include_once 'plantillas/navbar.inc.php';
?>

<div class="container-fluid text-center">
    <div class="jumbotron"> 
        <b><h3>Universidad Nacional Experimental Politécnica</h3>
            <h3>"Antonio José de Sucre"</h3>
            <h3>Núcleo Guarenas</h3></b>
        <p>
            <h2>Síguenos en: @unexpoNGoficial</h2>
        </p>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3">
            <div class="row">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <span class="glyphicon glyphicon-search" aria-hidden="true"></span> Búsqueda
                    </div>
                    <div class="panel-body">
                        <form role="form" method="post" action="<?php echo RUTA_BUSCAR;?>">
                            <div class="form-group">
                                <input type="search" name="termino-buscar" class="form-control" placeholder="¿Qué buscas?">
                            </div>
                            <button type="submit" name="buscar" class="form-control btn btn-primary">Buscar</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="cool-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <span class="glyphicon glyphicon-filter" aria-hidden="true"></span>
                            Filtro
                        </div>
                        <div class="panel-body">

                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="cool-md-12">
                    <div class="panel panel-default"> 
                        <div class="panel-heading">
                            <i class="fas fa-map-marker-alt"></i> UBICACIÓN: SEDE TERRAZAS
                        </div>
                        <div class="panel-body text-center">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6598.415304184769!2d-66.60582874215191!3d10.465841981967966!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf658d713103890b1!2sUniversidad%20Nacional%20Experimental%20Polit%C3%A9cnica%20UNEXPO!5e0!3m2!1ses!2sve!4v1578280164763!5m2!1ses!2sve" width="300" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                        </div>
                    </div>
                </div>
            </div> 
            <div class="row">
                <div class="cool-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fas fa-map-marker-alt"></i> UBICACIÓN: SEDE NARANJOS
                        </div>
                        <div class="panel-body text-center">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15693.20009476164!2d-66.5952909447903!3d10.476998046908447!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8c2bab1a2182d905%3A0x9ec53928c3e767f9!2sN%C3%BAcleo%20UNEXPO%20Guarenas!5e0!3m2!1ses!2sve!4v1578279948015!5m2!1ses!2sve" width="300" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-9">
            <?php
            EscritorEntradas::escribir_entradas();
            ?>
        </div>
    </div>
</div>
<?php
include_once 'plantillas/documento-cierre.inc.php';
?>




