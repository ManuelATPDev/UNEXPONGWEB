<?php
include_once 'app/EscritorEntradas.inc.php';

$busqueda = null;

$resultados = null;
$resultados_avanzados = null;

$buscar_titulo = false;
$buscar_contenido = false;
$buscar_autor = false;

if (isset($_POST['buscar']) && isset($_POST['termino-buscar']) && !empty($_POST['termino-buscar'])) {
    $busqueda = $_POST['termino-buscar'];

    Conexion::abrir_conexion();
    $resultados = RepositorioEntrada::buscar_entradas_todos_los_campos(Conexion::obtener_conexion(), $busqueda);

    Conexion::cerrar_conexion();
}

if (isset($_POST['busqueda_avanzada']) && isset($_POST['campos'])) {

    if (in_array("titulo", $_POST['campos'])) {
        $buscar_titulo = true;
    }

    if (in_array("contenido", $_POST['campos'])) {
        $buscar_contenido = true;
    }

    if (in_array("autor", $_POST['campos'])) {
        $buscar_autor = true;
    }

    if ($_POST['fecha'] == "recientes") {
        $orden = "DESC";
    }
    if ($_POST['fecha'] == "antiguas") {
        $orden = "ASC";
    }

    if (isset($_POST['termino-buscar']) && !empty($_POST['termino-buscar'])) {
        $busqueda = $_POST['termino-buscar'];

        Conexion::abrir_conexion();

        if ($buscar_titulo) {
            $entradas_por_titulo = RepositorioEntrada::buscar_entradas_por_titulo(Conexion::obtener_conexion(), $busqueda, $orden);
            $resultados_avanzados_titulo = $entradas_por_titulo;
        }

        if ($buscar_contenido) {
            $entradas_por_contenido = RepositorioEntrada::buscar_entradas_por_contenido(Conexion::obtener_conexion(), $busqueda, $orden);
            $resultados_avanzados_contenido = $entradas_por_contenido;
        }

        if ($buscar_autor) {
            $entradas_por_autor = RepositorioEntrada::buscar_entradas_por_autor(Conexion::obtener_conexion(), $busqueda, $orden);
            $resultados_avanzados_autor = $entradas_por_autor;
        }

        Conexion::cerrar_conexion();
    }
}

$titulo = "Buscar en UnexpoNGWeb";

include_once 'plantillas/documento-apertura.inc.php';
include_once 'plantillas/navbar.inc.php';
?>

<div class="container">
    <div class="row">
        <div class="jumbotron">
            <h1 class="text-center"> Buscar en UnexpoNGWeb</h1>
            <br>
            <div class="row">
                <div class="col-md-2">
                </div>
                <div class="col-md-8">
                    <form role="form" method="post" action="<?php echo RUTA_BUSCAR; ?>">
                        <div class="form-group">
                            <input type="search" name="termino-buscar" class="form-control" placeholder="¿Qué buscas?" required <?php echo "value='" . $busqueda . "'" ?>>
                        </div>
                        <button type="submit" name="buscar" class="form-control btn btn-primary btn-buscar">Buscar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="panel-group">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        Búsqueda avanzada<a data-toggle="collapse" href="#avanzada"> <span class="glyphicon glyphicon-check" aria-hidden="true"></span></a>
                    </h4>
                </div>
                <div id="avanzada" class="panel-collapse collapse">
                    <div class="panel-body">
                        <form role="form" method="post" action="<?php echo RUTA_BUSCAR; ?>">
                            <div class="form-group">
                                <input type="search" name="termino-buscar" class="form-control" placeholder="¿Qué buscas?" required <?php echo "value='" . $busqueda . "'" ?>>
                            </div>
                            <p>Buscar en los siguientes campos:</p>
                            <label class="checkbox-inline">
                                <input type="checkbox" value="titulo" name="campos[]"
                                <?php
                                if (isset($_POST['busqueda_avanzada'])) {
                                    if ($buscar_titulo) {
                                        echo "checked";
                                    }
                                } else {
                                    echo "checked";
                                }
                                ?>
                                       >Título
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" value="contenido" name="campos[]" 
                                <?php
                                if (isset($_POST['busqueda_avanzada'])) {
                                    if ($buscar_contenido) {
                                        echo "checked";
                                    }
                                } else {
                                    echo "checked";
                                }
                                ?>
                                       >Contenido
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" value="autor" name="campos[]" 
                                <?php
                                if (isset($_POST['busqueda_avanzada'])) {
                                    if ($buscar_autor) {
                                        echo "checked";
                                    }
                                }
                                ?>
                                       >Autor
                            </label>
                            <br>
                            <br>
                            <p>Ordenar por:</p>
                            <label class="radio-inline">
                                <input type="radio" name="fecha"  value="recientes" 
                                <?php
                                if (isset($_POST['busqueda_avanzada']) && isset($orden) && $orden == 'DESC') {
                                    echo "checked";
                                }

                                if (!isset($_POST['busqueda_avanzada'])) {
                                    echo "checked";
                                }
                                ?>
                                       >Entradas más recientes
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="fecha" value="antiguas" 
                                <?php
                                if (isset($_POST['busqueda_avanzada']) && isset($orden) && $orden == 'ASC') {
                                    echo 'checked';
                                }
                                ?>
                                       >Entradas más antigüas
                            </label>
                            <br>
                            <br>
                            <label class="radio-inline">
                                <input type="radio" name="tipo" value="todos">Todos
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="tipo" value="industrial">Informacion Entrenamiento Industrial y Pasantías
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="tipo" value="tramites">Informacion y Trámites DACE
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="tipo" value="servicio">Servicio Comunitario
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="tipo" value="cultura">Cultura
                            </label>
                            <br>
                            <br>
                            <button type="submit" name="busqueda_avanzada" class="btn btn-primary btn-buscar">Búsqueda avanzada</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container" id="resultados">
    <div class="row">
        <div class="col-md-12">
            <div class="page-header">
                <h1>Resultados
                    <?php
                    if (isset($_POST['buscar']) && $resultados) {
                        echo " ";
                        ?>
                        <small><?php echo count($resultados); ?></small>
                        <?php
                    } else if (isset($_POST['busqueda_avanzada']) && $resultados_avanzados_titulo) {
                        echo " ";
                        ?>
                        <small><?php echo count($resultados_avanzados_titulo); ?></small>
                        <?php
                    }
                    ?>
                </h1>
            </div>
        </div>
    </div>

    <?php
    if (isset($_POST['buscar'])) {
        if ($resultados) {
            EscritorEntradas::mostrar_entradas_busqueda($resultados);
        } else {
            ?>
            <h3>No hay Coincidencias</h3>
            <?php
        }
    } else if (isset($_POST['busqueda_avanzada'])) {
        if ($entradas_por_titulo || $entradas_por_contenido || $entradas_por_autor) {
            $parametros = count($_POST['campos']);
            $ancho_columnas = 12 / $parametros;
            ?>
            <div class="row">
                <?php
                for ($i = 0; $i < $parametros; $i++) {
                    ?>
                    <div class="<?php echo 'col-md-' . $ancho_columnas; ?> text center">
                        <h4><?php echo 'Coincidencias en ' . $_POST['campos'][$i]; ?> <?php
                            switch ($_POST['campos'][$i]) {
                                case "titulo":
                                    echo ": ";
                                    ?><?php
                                    echo count($resultados_avanzados_titulo);
                                    break;
                                case "contenido":
                                    echo ": ";
                                    ?><?php
                                    echo count($resultados_avanzados_contenido);
                                    break;
                                case "autor":
                                    echo ": ";
                                    ?><?php
                                    echo count($resultados_avanzados_autor);
                                    break;
                            }
                            ?></h4>
                        <br>
                        <br>
                        <?php
                        switch ($_POST['campos'][$i]) {
                            case "titulo":
                                EscritorEntradas::mostrar_entradas_busqueda_multiple($entradas_por_titulo);
                                break;
                            case "contenido":
                                EscritorEntradas::mostrar_entradas_busqueda_multiple($entradas_por_contenido);
                                break;
                            case "autor":
                                EscritorEntradas::mostrar_entradas_busqueda_multiple($entradas_por_autor);
                                break;
                        }
                        ?>
                    </div>
                    <?php
                }
                ?>
            </div>
            <?php
        } else {
            ?>
            <h3>No hay coincidencias</h3>
            <br>
            <br>
            <?php
        }
    }
    ?>
</div>

<?php
include_once 'plantillas/documento-cierre.inc.php';
?>
