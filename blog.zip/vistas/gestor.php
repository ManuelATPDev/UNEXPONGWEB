<?php

include_once 'plantillas/documento-apertura.inc.php';
include_once 'plantillas/navbar.inc.php';
include_once 'plantillas/panel-control-apertura.inc.php';

switch ($gestor_actual) {
    case 'general':
        $cantidad_entradas_activas = RepositorioEntrada::contar_entradas_activas(Conexion::obtener_conexion(), $_SESSION['id_usuario']);
        $cantidad_entradas_inactivas = RepositorioEntrada::contar_entradas_inactivas(Conexion::obtener_conexion(), $_SESSION['id_usuario']);
        $cantidad_comentarios = RepositorioComentario::contar_comentarios(Conexion::obtener_conexion(), $_SESSION['id_usuario']);
        $cantidad_tramites_activos = RepositorioTramite::contar_tramites_activos(Conexion::obtener_conexion(), $_SESSION['id_usuario']);
        $cantidad_tramites_inactivos = RepositorioTramite::contar_tramites_inactivos(Conexion::obtener_conexion(), $_SESSION['id_usuario']);
       


        include_once 'plantillas/gestor-general.inc.php';
        break;
    case 'entradas':
        $array_entradas = RepositorioEntrada::obtener_entradas_usuario_fecha_descendente(Conexion::obtener_conexion(), $_SESSION['id_usuario']);
        
        include_once 'plantillas/gestor-entradas.inc.php';
        break;
    case 'comentarios':
        echo 'HOLA bb';
        break;
    case 'tramites':
        echo 'HOLA bbbb';
        break;
}

include_once 'plantillas/panel-control-cierre.inc.php';
include_once 'plantillas/documento-cierre.inc.php';
